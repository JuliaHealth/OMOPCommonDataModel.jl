
-- spark does not support indexes


-- spark does not support indexes

-- spark does not support indexes
-- spark does not support indexes

-- spark does not support indexes
-- spark does not support indexes

-- spark does not support indexes
-- spark does not support indexes

-- spark does not support indexes
-- spark does not support indexes

-- spark does not support indexes
-- spark does not support indexes

-- spark does not support indexes
-- spark does not support indexes

-- spark does not support indexes
-- spark does not support indexes


-- spark does not support indexes
-- spark does not support indexes

-- spark does not support indexes

-- spark does not support indexes
-- spark does not support indexes
-- spark does not support indexes
-- spark does not support indexes




-- spark does not support indexes

-- spark does not support indexes

-- spark does not support indexes

-- spark does not support indexes


-- spark does not support indexes
-- spark does not support indexes
-- spark does not support indexes
-- spark does not support indexes




-- spark does not support indexes
-- spark does not support indexes



-- spark does not support indexes

-- spark does not support indexes
-- spark does not support indexes
-- spark does not support indexes

-- spark does not support indexes