library(testthat)
library(CommonDataModel)

test_check("CommonDataModel")
