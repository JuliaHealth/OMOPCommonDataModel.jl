## R CMD check results

* This is a new release

# Update based on reviewer feedback
  - turned off tests when environment variables are not set
  - removed vignetteBuilder field from DESCRIPTION
  - added return values in function documentation
  - updated buildRelease.R default output folder to tempdir()

0 errors | 0 warnings | 0 notes


