Common-Data-Model / BigQuery
=================

This folder contains the script for Google BigQuery. 
