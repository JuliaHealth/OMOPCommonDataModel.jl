© 2014  Observational Health Data Sciences and Informatics

This work is based on work by the Observational Medical Outcomes Partnership (OMOP) and used under license from the FNIH at http://omop.fnih.org/publiclicense. 

All derivative work after the OMOP CDM v4 specification is dedicated to the public domain.  Observational Health Data Sciences and Informatics (OHDSI) has waived all copyright and related or neighboring rights to the extent allowed by law.

![](http://www.ohdsi.org/web/wiki/lib/exe/fetch.php?cache=&w=88&h=31&tok=3977bb&media=documentation:cdm:cdm:public_domain.png)
http://creativecommons.org/publicdomain/zero/1.0/ 
