[LOCATION](https://github.com/OHDSI/CommonDataModel/wiki/LOCATION)  
[CARE_SITE](https://github.com/OHDSI/CommonDataModel/wiki/CARE_SITE)  
[PROVIDER](https://github.com/OHDSI/CommonDataModel/wiki/PROVIDER)      

These tables describe the healthcare provider system responsible for administering the healthcare of the patient, rather than the demographic or clinical events the patient experienced.
Below provides an entity-relationship diagram highlighting the tables within the Standardized Health System portion of the OMOP Common Data Model:

![Health system tables entity-relationship diagram](http://www.ohdsi.org/web/wiki/lib/exe/fetch.php?w=800&tok=82724f&media=documentation:cdm:standard_health_system_data_tables.png)\
  