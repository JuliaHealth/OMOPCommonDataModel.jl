# Derived tables

R script is used to take parametized sql (in this folder) and generate flavored SQL files  (see respective flavor folder)


